import streamlit as st
import requests

st.title("Contact Us")

with st.form("contact_form"):
    name = st.text_input("Your Name")
    email = st.text_input("Your Email")
    message = st.text_area("Your Message")
    submitted = st.form_submit_button("Send")

    if submitted:
        if name and email and message:
            formspree_url = "https://formspree.io/f/mkgjkwnq"

            data = {
                "name": name,
                "email": email,
                "message": message
            }

            response = requests.post(formspree_url, data=data)

            if response.status_code == 200:
                st.success("Thanks for your message!")
            else:
                st.error("There was an error sending your message.")
        else:
            st.warning("Please fill in all fields before submitting.")
