import streamlit as st
st.title("Hobbies")
st.divider()
st.image("images/drawing.jpg", width=300)
st.write("Image of my latest sketches")
st.divider()
st.image("images/tennis.jpg", width=300)
st.write("Image of me playing tennis with my friends")