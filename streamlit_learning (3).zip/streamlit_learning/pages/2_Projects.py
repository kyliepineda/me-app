import streamlit as st

st.title("Projects")
st.divider()

import streamlit as st
st.title("BMI Calculator")
st.image("images/bmi.jpg")
number1=st.number_input("Enter your weight(lbs)")
number2=st.number_input("Enter your height(inch)")

st.markdown("""
| BMI | Status |
| ------ | ------ |
| <=18.4 | underweight |
| 18.5-24.9 | normal |
| 25-39 | overweight |
| >=40 | obese |
""")
if st.button("Calculate BMI"):
    bmi=((703*number1)/(number2**2))
    st.success(f"Your BMI is: {round(bmi,2)}")
    if bmi<=19.4:
        st.error("You are underweight")
    elif bmi>=18.5 and bmi<=24.9:
        st.error("You are normal weight")
    elif bmi >= 25 and bmi <= 39.9:
        st.error("You are overweight")
    else:
        st.error("You are obese")

st.divider()

import streamlit as st
st.title("Simple Addition App")
st.image("images/addition.png", width=300)
number1=st.number_input("Enter first number:")
number2=st.number_input("Enter second number")
if st.button("Add"):
    st.write("The output is", number2+number1)
else:
    st.write("")