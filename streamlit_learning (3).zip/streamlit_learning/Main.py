import streamlit as st
st.set_page_config(
    page_title="Main Page",
    page_icon="😎"
)
st.title("A Little About Me. . . ")
st.divider()
st.image("images/loopy.jpg", width=200)
st.write("Hi, I'm Kylie and I'm 13 years old, turning 14 in April! I have lots of hobbies like drawing and tennis. Some of my favorite things include the color beige and dogs, obviously. In life, I aspire to work in the medical field so people won't have to go through the same kind of pain my Dad does due to his heart condition.")
st.divider()
st.title("Passions")
st.markdown("""
- Drawing
- Biology Studies
- Tennis

""")